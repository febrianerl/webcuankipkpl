<div class="col-lg-9 mt-2">
        <div class="card">
  <div class="card-header">
    Featured
  </div>
  <div class="card-body">
    <h5 class="card-title">Home</h5>
    <p class="card-text">With supporting text below as a natural lead-in to additional content. Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora quidem inventore, eveniet minima animi amet perspiciatis quaerat excepturi porro voluptatibus exercitationem labore, veritatis adipisci! Inventore, placeat corporis? Eum, optio dicta!</p>
    <a href="#" class="btn btn-primary">Go somewhere</a>
  </div>
</div>
        </div>